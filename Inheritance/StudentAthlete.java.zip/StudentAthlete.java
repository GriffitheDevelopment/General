
public class StudentAthlete extends student
{
    private String sport;
    private String level;

  public StudentAthlete (String _name_, int _id_, double _gpa_,String _sport_, String _level_){
      super (_name_,_id_,_gpa_);
      sport=_sport_;
      level=_level_;
        
        
    }  
    public String toString(){
        return super.toString()+" and plays " +sport +" on the level of " + level;
     }
}