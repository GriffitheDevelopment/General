public class student
{
    private String name;
    private int id;
    private double gpa;
    
    
    public student (String _name_, int _id_, double _gpa_){
        name=_name_;
        id=_id_;
        gpa=_gpa_;
        
    }
    public String getName(){
        return name;
    }
    public int getId(){
        return id;
    }
    public double getGpa(){
        return gpa;
    }
    public String toString(){
        return name+": id number "+ id +" has a current gpa of "+gpa;
     }
}