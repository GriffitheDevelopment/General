public class instrument
{
    private String name;
    private String family;
    
    
    
    public instrument (String _name_,String _family_){
        name=_name_;
        family=_family_;
        
    }
    public String getName(){
        return name;
    }
    public String getFamiy(){
        return family;
    }
    public String toString(){
        return name+"is part of the "+ family  +" family.";
     }
}
