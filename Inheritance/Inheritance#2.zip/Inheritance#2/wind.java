
public class wind extends instrument 
{
    private String sport;
    private String level;
    private boolean reed;

  public wind (String _name_, String _family_,boolean _reed_){
      super (_name_,_family_);
      reed=_reed_;
      
        
        
    }  
    public String toString(){
        return super.toString()+" and has a reed: "+reed;
     }
}
