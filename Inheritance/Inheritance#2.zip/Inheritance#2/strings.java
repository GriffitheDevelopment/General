
public class strings extends instrument
{
    private boolean bow;

  public strings (String _name_,String _family_, boolean _bow_){
      super (_name_,_family_);
      bow=_bow_;
    
        
        
    }  
    public String toString(){
        return super.toString()+" and has a bow: "+bow;
     }
}
